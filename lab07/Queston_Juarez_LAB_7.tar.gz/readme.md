Trees
Pros: Keeps Data sorted in a proper order, Overall best Omega run time,
fast at resorting.
cons: Very slow in inserting and finding elements, Uses more memory,
Worse average-case comppared to hash-tables O(logn)

Hash-Table
Pros: Extremely fast insertion and finding elements, more memory effiecient,
Good average case of O(1),
cons: Nothing is sorted properly, unpredictable, depending on hash there is more
likely to be collisions.

Possible Tests
I would like to see how easily it is to change an element as well as how quickly
we can traverse the entire container.