//Course: CS 14 Spring 2015
//
//First name: <Queston>
//Last name: <Juarez>
//Course username: <qjuar001>
//Email address: <qjuar001@ucr.edu>
//
//Lecture section: <002>
//Lab section: <23>
//TA:<Dingwen>
//
//lab:<03>
//
//I hereby certify that the code in this file
//is ENTIRELY my own original work.
//=================================================================

#include <iostream>
#include <stack>
#include "lab3.h"

using namespace std;

int main()
{
    // Test TwoStackFixed class
    TwoStackFixed<int> test1(10, 5);
    test1.pushStack1(5);
    test1.pushStack1(4);
    test1.pushStack1(3);
    test1.pushStack1(2);
    test1.pushStack1(1);
    test1.printStack1();//push to first stack and print
    
    test1.pushStack2(1);
    test1.pushStack2(2);
    test1.pushStack2(3);
    test1.pushStack2(4);
    test1.pushStack2(5);
    test1.printStack2();//push to second stack and print
    
    test1.pushStack1(0);//These should cause errors.
    test1.pushStack2(6);
    
    TwoStackFixed<char> test2(7, 4);
    test2.pushStack1('a');
    test2.pushStack1('b');
    test2.printStack1();//Add elements to stack 1.
    
    test2.popStack1();
    test2.printStack1();
    test2.popStack1();
    test2.popStack1();
    test2.printStack1();//Test taking away elements form stack
    
    test2.pushStack2('z');//Add to second stack and print.
    test2.pushStack2('y');
    test2.pushStack2('x');
    test2.printStack2();
    
    test2.popStack2();//Test the pop on the second stack.
    test2.popStack2();
    test2.printStack2();
    
    test2.popStack2();
    test2.printStack2();
    cout << "End of first testing." << endl << endl;
    //__________________________________________________________________________
    //Test TwoStackOptimal class
    TwoStackOptimal<int> test3(5);//Fills stack one to max then prints.
    test3.pushFlexStack1(1);
    test3.pushFlexStack1(2);
    test3.pushFlexStack1(3);
    test3.pushFlexStack1(4);
    test3.pushFlexStack1(5);
    test3.printStack1();
    test3.pushFlexStack1(6);// Should produce an error.
    test3.pushFlexStack2(5); //Should produce an error.
    
    test3.popFlexStack1();//Pop off an element on stack 1
    test3.printStack1();
    test3.pushFlexStack2(10);//Add an element to second stack.
    test3.printStack2();
    test3.pushFlexStack2(9);//Should produce an error.
    test3.popFlexStack1();
    test3.popFlexStack1();
    test3.pushFlexStack2(9);
    test3.printStack1();
    test3.printStack2();
    
    TwoStackOptimal<char> test4(3);
    test4.pushFlexStack1('a');
    test4.pushFlexStack2('c');
    test4.printStack1();
    test4.printStack2();
    test4.pushFlexStack1('b');
    test4.printStack1();
    test4.pushFlexStack2('d'); //Should produce an error.
    test4.pushFlexStack1('c'); //Should produce an error.
    cout << "End of second testing." << endl << endl;
    
    //__________________________________________________________________________
    //Testing Tower of Hanoi
    
    // int n = 0;
    stack<int> A;
    A.push(3);
    A.push(2);
    A.push(1);
    // n = A.size();
    stack<int> B;
    stack<int> C;
    showTowerStates(3,A,B,C);
    
    return 0;
}