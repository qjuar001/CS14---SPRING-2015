//Course: CS 14 Spring 2015
//
//First name: <Queston>
//Last name: <Juarez>
//Course username: <qjuar001>
//Email address: <qjuar001@ucr.edu>
//
//Lecture section: <002>
//Lab section: <23>
//TA:<Dingwen>
//
//lab:<03>
//
//I hereby certify that the code in this file
//is ENTIRELY my own original work.
//=================================================================

#include <iostream>
#include <cstdlib>
#include <stack>



using namespace std;

template<class T>
class TwoStackFixed
{
    private:
        T* arrStack; //Array
        int size;
        int max;
        int leftsz;
        int rightsz;
        int capleft;
        int capright;
        
    public:
        TwoStackFixed(int size, int maxtop);
        void pushStack1(T value);
        void pushStack2(T value);
        T popStack1();
        T popStack2();
        bool isFullStack1();
        bool isFullStack2();
        bool isEmptyStack1();
        bool isEmptyStack2();
        void printStack1();
        void printStack2();
};

template<class T>
class TwoStackOptimal
{
    private:
        T* arrStack; //Array
        int size;
        int leftsz;
        int rightsz;
    
    public:
        TwoStackOptimal(int size);
        void pushFlexStack1(T value);
        void pushFlexStack2(T value);
        T popFlexStack1();
        T popFlexStack2();
        bool isFullStack1();
        bool isFullStack2();
        bool isEmptyStack1();
        bool isEmptyStack2();
        void printStack1();
        void printStack2();
};

//______________________________________________________________________________
//TwoStackFixed member functions

//Constructor that creates an array of type T.
template<class T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop) 
    : size(size), max(maxtop), leftsz(0), rightsz(0)
{ 
    arrStack = new T[size];
    if(max == size)
    {
        cout << "Error: max cannot be >= size." << endl;
        exit(1);
    }
    capleft = max;
    capright = size - max;
}

//Adds an element to the left stack
template<class T>
void TwoStackFixed<T>::pushStack1(T value)
{
    if(isFullStack1())
    {
        cout << "Error: Stack 1 is full." << endl;
        return;
    }
    else
    {
        arrStack[leftsz] = value;
        leftsz++;
    }
}

//Adds an element to the right stack
template<class T>
void TwoStackFixed<T>::pushStack2(T value)
{
    if(isFullStack2())
    {
        cout << "Error: Stack 2 is full." << endl;
        return;
    }
    else
    {
        arrStack[size - 1 - rightsz] = value;
        rightsz++;
    }
}

//Takes off the top element of the first stack.
template<class T>
T TwoStackFixed<T>::popStack1()
{
    T last;
    if(isEmptyStack1())
    {
        cout << "Error: stack 1 is empty." << endl;
    }
    else
    {
        last = arrStack[leftsz - 1];
        leftsz--;
    }
    return last;
}

//Takes off the top element of the second stack
template<class T>
T TwoStackFixed<T>::popStack2()
{
    T last;
    if(isEmptyStack2())
        cout << "Error: stack 2 is empty." << endl;
    else
    {
        last = arrStack[size - rightsz];
        rightsz--;
    }
    return last;
}

//Checks to see if stack 1 is full or not
template<class T>
bool TwoStackFixed<T>::isFullStack1()
{
    if(leftsz == capleft)
        return true;
    else 
        return false;
}

//Checks to see if stack 2 is full or not
template<class T>
bool TwoStackFixed<T>::isFullStack2()
{
    if(rightsz == capright)
        return true;
    else
        return false;
}

//Checks to see if stack 1 is empty
template<class T>
bool TwoStackFixed<T>::isEmptyStack1()
{
    if(leftsz == 0)
        return true;
    else
        return false;
}

//Checks to see if stack 2 is empty
template<class T>
bool TwoStackFixed<T>::isEmptyStack2()
{
    if(rightsz == 0)
        return true;
    else
        return false;
}

template <class T> 
void TwoStackFixed<T>::printStack1()
{
    if(isEmptyStack1()){
        cout << "Error: printStack1 called on empty stack" << endl;
        return;
    }
    int location = 0;
    while(location <= leftsz - 1)
    {
        cout << arrStack[location] << " ";
        ++location;
    }
    cout << endl;
}

template <class T> 
void TwoStackFixed<T>::printStack2()
{
    if(isEmptyStack2())
    {
        cout << "Error: printStack2 called on empty stack" << endl;
        return;
    }
    int location = size - 1;
    while(location >= size - rightsz)
    {
        cout << arrStack[location] << " ";
        --location;
    }
    cout << endl;
}


//______________________________________________________________________________
//Member functions for twoStackOptimal

//Constructor that initialises the size.
template<class T>
TwoStackOptimal<T>::TwoStackOptimal(int size)
 : size(size), leftsz(0), rightsz(0)
{
    arrStack = new T[size];
}

//Pushes a new value onto the left stack.
template<class T>
void TwoStackOptimal<T>::pushFlexStack1(T value)
{
    if(isFullStack1())
    {
        cout << "Error: stack 1 is full or cannot be filled." << endl;
        return;
    }
    arrStack[leftsz] = value;
    leftsz++;
}

//Pushes a new value onto the right stack.
template<class T>
void TwoStackOptimal<T>::pushFlexStack2(T value)
{
    if(isFullStack2())
    {
        cout << "Error: stack 2 is full or cannot be filled." << endl;
        return;
    }
    arrStack[size - rightsz - 1] = value;
    rightsz++;
}

//Takes away the last element put into the first stack.
template<class T>
T TwoStackOptimal<T>::popFlexStack1()
{
    T last;
    if(isEmptyStack1())
        cout << "Error: stack 1 is empty." << endl;
    else
    {
        last = arrStack[leftsz - 1];
        leftsz--;
    }
    return last;
}

//Takes away the last element put inot the second stack.
template<class T>
T TwoStackOptimal<T>::popFlexStack2()
{
    T last;
    if(isEmptyStack2())
        cout << "Error: stack 2 is empty." << endl;
    else
    {
        last = arrStack[size - rightsz];
        rightsz--;
    }
    return last;
}

//Determines if the left stack is full.
template<class T>
bool TwoStackOptimal<T>::isFullStack1()
{
    if(leftsz + rightsz == size)
        return true;
    else
        return false;
}

//Determines if the right stack is full
template<class T>
bool TwoStackOptimal<T>::isFullStack2()
{
    if(leftsz + rightsz == size)
        return true;
    else
        return false;
}

//Determines if the left stack is empty.
template<class T>
bool TwoStackOptimal<T>::isEmptyStack1()
{
    if(leftsz == 0)
        return true;
    else
        return false;
}

//Determines if the right stack is empty.
template<class T>
bool TwoStackOptimal<T>::isEmptyStack2()
{
    if(rightsz == 0)
        return true;
    else
        return false;
}

//Prints out the first stack from bottom to top
template <class T> 
void TwoStackOptimal<T>::printStack1()
{
    if(isEmptyStack1()){
        cout << "Error: printStack1 called on empty stack" << endl;
        return;
    }
    int location = 0;
    while(location <= leftsz - 1)
    {
        cout << arrStack[location] << " ";
        ++location;
    }
    cout << endl;
}

//Prints out the second stack from bottom to top
template <class T> 
void TwoStackOptimal<T>::printStack2()
{
    if(isEmptyStack2())
    {
        cout << "Error: printStack2 called on empty stack" << endl;
        return;
    }
    int location = size - 1;
    while(location >= size - rightsz)
    {
        cout << arrStack[location] << " ";
        --location;
    }
    cout << endl;
}

//______________________________________________________________________________
//Function for the Tower of Hanoi


void tower(int a,char A,char B,char C){
    if(a==1){
       cout<<"\t\tMove disc 1 from "<<A<<" to "<<C<<"\n";
       return;
    }
    else{
       tower(a-1,A,C,B);
       cout<<"\t\tMove disc "<<a<<" from "<<A<<" to "<<C<<"\n";
       tower(a-1,B,C,A);
    }
}

template<typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C)
{
    tower(n, 'A', 'B', 'C');
}