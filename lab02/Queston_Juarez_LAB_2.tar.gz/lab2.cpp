//Course: CS 14 Spring 2015
//
//First name: <Queston>
//Last name: <Juarez>
//Course username: <qjuar001>
//Email address: <qjuar001@ucr.edu>
//
//Lecture section: <002>
//Lab section: <23>
//TA:<Dingwen>
//
//lab:<01>
//
//I hereby certify that the code in this file
//is ENTIRELY my own original work.
//=================================================================

#include <iostream>
#include <forward_list>
#include "lab2.h"

using namespace std;

template <class T>
List<T>::List()
    :head(0), tail(0), number_of_nodes(0)
    {}

template <class T>
List<T>::List(const List<T>& in_list){ // copy constructor
    head = 0;
    tail = 0;
    if(in_list.head == 0){
        return;
    }
    else{
        Node<T> *current = in_list.head;
        while(current != 0){
            this->push_back(current->data);
            current=current->next;
        }
    }
}
    
template <class T>
List<T>::~List(){
    Node<T> *current = head;
    while(current != 0){
        delete current;
        current = current->next;
    }
    number_of_nodes = 0;
    head = 0;
    tail = 0;
}

template <class T>
List<T> List<T>::elementSwap(int pos){
    if(pos > number_of_nodes){ // cant swap if pos is in last node
        return *this;
    }
    else if(number_of_nodes == 1) return *this;
    if(pos == 0){
        Node<T> *pos_A = head;
        Node<T> *pos_B = head->next;
        pos_A->next = pos_B->next;
        head = pos_B;
        head->next = pos_A;
        return *this;
    }
    else{
        Node<T> *pos_A = head; // current will store pos -1
        for(int i = 0; i < pos - 1; ++i){ //this creates a pointer to pos - 1;
            pos_A = pos_A->next;
        }
        Node<T> *pos_B = pos_A->next; // this pointer points to pos
        Node<T> *pos_C = pos_B->next; //points to pos + 1
        
        pos_A->next = pos_C;
        pos_B->next = pos_C->next;
        pos_C->next = pos_B;
        return *this;
    }
    
}

template <class T>
void List<T>::display() const{ 
    Node<T> *current = head; 
    while(current != 0){ 
        cout << current->data; 
        current = current->next; 
    } 
    cout << endl;
    
}


template <class T>
void List<T>::push_back(T value){
    number_of_nodes = number_of_nodes + 1;
    Node<T> *temp = new Node<T>(value);
    if(head == 0){
        head = temp;
        tail = temp;
        return;
    }
    else{
        tail->next = temp;
        tail = tail->next;
    }
}

//______________________________________________________________________________
//Functions that are seperate from class List.
// #1
//Helper function that helps determine if a number is a Prime.
bool isPrime(int i)
{
    if(i < 2) return false; // 1 is not a prime
    if(i == 2) return true; //If equal to 2 then it is a prime
    if(i % 2 == 0) return false; //If even then not prime
    for(int x = 3; (x * x) <= i; x+=2) // iterate until x*x > i or i % x == 0;
    {
        if(i % x == 0) return false;
    }
    return true;
}

// #1
//Searches through a forward_List and determines how many primes there are.
int primeCount(forward_list<int> lst)
{
    if(lst.empty()) return 0; //Check if empty
    if(isPrime(lst.front())) //Check if the first element is prime
    {
        lst.pop_front(); // Take element away and add one then call recursively.
        return 1 + primeCount(lst);
    }
    else
    {
        lst.pop_front(); // Take away element then call recursion
        return primeCount(lst);
    }
}

// #3
template <typename Type>
forward_list<Type> listCopy( forward_list <Type> L, forward_list <Type> P )
{
    //Create a new list and copy L into it backwards.
    forward_list<Type> copy;
    typename forward_list<Type>::iterator i = L.begin();
    while(i != L.end())
    {
        copy.push_front(*i);
        i++;
    }
    //Create another new list and copy P into it backwards
    forward_list<Type> copy2;
    typename forward_list<Type>::iterator j = P.begin();
    while(j != P.end())
    {
        copy2.push_front(*j);
        j++;
    }
    //push_front all the elements from copy2 into copy in order to put list P
    // infront of list L.
    typename forward_list<Type>::iterator k = copy2.begin();
    while(k != copy2.end())
    {
        copy.push_front(*k);
        k++;
    }
    return copy;
}

// #4
template <typename Type>
void printLots (forward_list<Type> L, forward_list <int> P)
{
    if(L.empty() || P.empty()) return;//If either is empty then return.
    
    forward_list<int>::iterator i = P.begin();//Creates Iterator starting at P
    vector<int>Values;//Create an array to store vlaues of P
    while(i != P.end()) 
    {
        Values.push_back(*i);
        i++;
    }
    
    //Create an iterator that starts at beginning of list L.
    typename forward_list<Type>::iterator j = L.begin();
    int x = 0;//Postion in list L.
    int y = 0;//Position in the vector
    for(y = 0; j != L.end(); j++, y++) 
    {
        if(x > Values.size()-1) return;//If x is bigger than vector sz then stop
        
        if(Values.at(x) == y)//If value in position x in the vector is equal to
        {                       //y then add to x and print out iterator.
            ++x;
            cout << *j;
        }
    }
}

int main()
{
    forward_list<int> list = {1,2,3,4,5,6};
    forward_list<int> list2 = {7,8,9,10};
    forward_list<int> list3;
    list3 = listCopy(list, list2);
    typename forward_list<int>::iterator p = list3.begin();
    for(p = list3.begin(); p != list3.end(); p++)
        {
            cout << *p << " ";
        }
        cout << endl;
        
    cout << primeCount(list) << endl;
    
    forward_list<char> mylist = { 'a', 'b', 'c', 'd'};
    // cout << primeCount(mylist) << endl;
    forward_list<int> mylist1 = { 0, 3};
    printLots(mylist, mylist1);
    cout << endl;
    List<char> L1;
    L1.push_back('a');
    L1.push_back('b');
    L1.push_back('e');
    L1.display();
    L1.elementSwap(0);
    // List<char> L2(L1);
    // L2.display();
    L1.display();
    List<int> list1;
    list1.push_back(1);
    list1.display();
    list1.push_back(2);
    list1.push_back(3);
    list1.elementSwap(0);
    list1.display();
    list1.display();
    
    return 0;
}