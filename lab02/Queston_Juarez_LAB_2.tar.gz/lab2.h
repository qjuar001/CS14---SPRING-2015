//Course: CS 14 Spring 2015
//
//First name: <Queston>
//Last name: <Juarez>
//Course username: <qjuar001>
//Email address: <qjuar001@ucr.edu>
//
//Lecture section: <002>
//Lab section: <23>
//TA:<Dingwen>
//
//lab:<01>
//
//I hereby certify that the code in this file
//is ENTIRELY my own original work.
//=================================================================

#include <iostream>
#include <forward_list>
#include <vector>

using namespace std;

//Decleration and implimentation of Class List.
template <typename T> 
struct Node
{
    T data;
    Node *next;
    Node(T data) : data(data), next(0) {}
};


template <class T>
class List{
    private:
        Node<T> *head;
        Node<T> *tail;
        int number_of_nodes;

    public:
        List(); //done
        ~List(); // done
        void display() const; //done
        void push_front(int value); //done
        void push_back(T value); // done
        List<T> elementSwap(int pos);
        List<T>(const List<T>& in_list); //copy constructor

};


// //Implementation
// //______________________________________________________________________________
// template <class Type>
// List<Type>::List() :head(0), tail(0)
// {}

// template <class Type>
// List<Type>::~List()
// {
//     if(head == 0)
//     {
//         delete head;
//     }
//     else
//     {
//         cout << "test2" << endl;
//       while(this->size() > 0)
//         {
//             cout << "test1" << endl;
//             this->pop_front();
//         }
//         this->pop_front();
//     }
// }

// template <class Type>
// void List<Type>::display() const
// {
//     Node<Type>* curr = head;
//     if(head == 0)
//     { }
//     else
//     {
//         if(curr->next != 0)
//         {
//             while(curr->next != 0)
//             {
//                 cout << curr->data << " ";
//                 curr = curr->next;
//             }
//             cout << curr->data;
//         }
//         else
//         {
//             cout << curr->data;
//         }
//     }
// }

// template <class Type>
// void List<Type>::push_front( Type value )
// {
//     Node<Type>* temp = new Node<Type>(value);
//     temp->next = head;
//     head = temp;
//     if(tail == 0)
//     {
//         tail = head;
//     }
// }

// template <class Type>
// void List<Type>::push_back( Type value )
// {
//     Node<Type>* temp = new Node<Type>(value);
//     if(head == 0)
//     {
//         tail = temp;
//         head = tail;
//     }
//     else
//     {
//         tail->next = temp;
//         tail = temp;
//     }
// }

// template <class Type>
// void List<Type>::pop_front()
// {
//     if(head == 0) return;
//     else if(head->next == 0)
//     {
//         delete head;
//         head = 0;
//         tail = 0;
//     }
//     else
//     {
//         Node<Type>* curr = head;
//         curr = curr->next;
//         delete head;
//         head = curr;
//     }
// }

// template <class Type>
// int List<Type>::size()
// {
//     if( head == 0) return 0;
    
//     int sz = 0;
//     Node<Type>* curr = head;
//     for(curr = head; curr->next != 0; curr = curr->next)
//     {
//         sz++;
//     }
//     return sz + 1;
// }
// //______________________________________________________________________________
// //Below this line are all the functions that are a part of lab2 for CS014.

// template <class Type>
// List<Type> List<Type>::elementSwap(int pos)
// {
//     // Check to see if list is empty or if size is one, returns origianl list.
//     if(this->head == 0 || this->size() == 1) return *this;
//     else if(pos < 0 || pos > this->size() - 1) //Bounds check for position.
//     {
//         cout << "Error: Out of bounds!" << endl;
//         return lst;
//     }
    
//     Node<Type>* curr = this->head;//Set two nodes to head to keep track of Nodes.
//     Node<Type>* temp = this->head;
//     for(int j = 0; j < pos; j++)//Make cuur equal to position and temp equal to
//     {                           // position - 1;
//         curr = curr->next;
//         if(j < pos - 1) temp = temp->next;
//     }
    
//     if(curr->next == 0) return *this;//If curr is at end of list then return list.
    
//     Node<Type>* next = curr->next;//Set next to one node ahead of curr.
//     if(pos == 0) //If pos is 0 then run this block of code.
//     {
//         thishead = next;
//         curr->next = next->next;
//         next->next = curr;
//     }
//     else//This block executes for any other position.
//     {
//         temp->next = next;
//         curr->next = next->next;
//         next->next = curr;
//     }
//     cout << "test5" << endl;
//     return lst;
// }

// //______________________________________________________________________________
// //Functions that are seperate from class List.
// // #1
// //Helper function that helps determine if a number is a Prime.
// bool isPrime(int i)
// {
//     if(i < 2) return false; // 1 is not a prime
//     if(i == 2) return true; //If equal to 2 then it is a prime
//     if(i % 2 == 0) return false; //If even then not prime
//     for(int x = 3; (x * x) <= i; x+=2) // iterate until x*x > i or i % x == 0;
//     {
//         if(i % x == 0) return false;
//     }
//     return true;
// }

// // #1
// //Searches through a forward_List and determines how many primes there are.
// int primeCount(forward_list<int> lst)
// {
//     if(lst.empty()) return 0; //Check if empty
//     if(isPrime(lst.front())) //Check if the first element is prime
//     {
//         lst.pop_front(); // Take element away and add one then call recursively.
//         return 1 + primeCount(lst);
//     }
//     else
//     {
//         lst.pop_front(); // Take away element then call recursion
//         return primeCount(lst);
//     }
// }

// // #3
// template <typename Type>
// forward_list<Type> listCopy( forward_list <Type> L, forward_list <Type> P )
// {
//     //Create a new list and copy L into it backwards.
//     forward_list<Type> copy;
//     typename forward_list<Type>::iterator i = L.begin();
//     while(i != L.end())
//     {
//         copy.push_front(*i);
//         i++;
//     }
//     //Create another new list and copy P into it backwards
//     forward_list<Type> copy2;
//     typename forward_list<Type>::iterator j = P.begin();
//     while(j != P.end())
//     {
//         copy2.push_front(*j);
//         j++;
//     }
//     //push_front all the elements from copy2 into copy in order to put list P
//     // infront of list L.
//     typename forward_list<Type>::iterator k = copy2.begin();
//     while(k != copy2.end())
//     {
//         copy.push_front(*k);
//         k++;
//     }
//     return copy;
// }

// // #4
// template <typename Type>
// void printLots (forward_list<Type> L, forward_list <int> P)
// {
//     if(L.empty() || P.empty()) return;//If either is empty then return.
    
//     forward_list<int>::iterator i = P.begin();//Creates Iterator starting at P
//     vector<int>Values;//Create an array to store vlaues of P
//     while(i != P.end()) 
//     {
//         Values.push_back(*i);
//         i++;
//     }
    
//     //Create an iterator that starts at beginning of list L.
//     typename forward_list<Type>::iterator j = L.begin();
//     int x = 0;//Postion in list L.
//     int y = 0;//Position in the vector
//     for(y = 0; j != L.end(); j++, y++) 
//     {
//         if(x > Values.size()-1) return;//If x is bigger than vector sz then stop
        
//         if(Values.at(x) == y)//If value in position x in the vector is equal to
//         {                       //y then add to x and print out iterator.
//             ++x;
//             cout << *j;
//         }
//     }
// }
